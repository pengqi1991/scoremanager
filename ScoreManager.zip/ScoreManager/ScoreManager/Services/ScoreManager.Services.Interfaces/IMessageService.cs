﻿
namespace ScoreManager.Services.Interfaces
{
    public interface IMessageService
    {
        string GetMessage();
    }
}
