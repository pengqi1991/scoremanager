﻿
namespace ScoreManager.Core
{
    public static class RegionNames
    {
        public const string ContentRegion = "ContentRegion";
        public const string MenuRegion = "MenuRegion";
    }
}
