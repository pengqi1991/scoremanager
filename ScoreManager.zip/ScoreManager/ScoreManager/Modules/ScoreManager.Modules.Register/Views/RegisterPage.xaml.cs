﻿using System.Windows.Controls;

namespace ScoreManager.Modules.Register.Views
{
    /// <summary>
    /// Interaction logic for RegisterPage
    /// </summary>
    public partial class RegisterPage : UserControl
    {
        public RegisterPage()
        {
            InitializeComponent();
        }
    }
}
