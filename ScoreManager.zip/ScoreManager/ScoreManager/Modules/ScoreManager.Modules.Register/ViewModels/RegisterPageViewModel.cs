﻿using Prism.Commands;
using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ScoreManager.Modules.Register.ViewModels
{
    public class RegisterPageViewModel : BindableBase
    {
        public RegisterPageViewModel()
        {

        }
    }
}
