﻿using ScoreManager.Core;
using System.Windows.Controls;

namespace ScoreManager.Modules.BasicInfo.Views
{
    /// <summary>
    /// Interaction logic for BasicInfoPage
    /// </summary>
    public partial class BasicInfoPage : UserControl
    {
        public BasicInfoPage()
        {
            InitializeComponent();
        }

      
    }
}
